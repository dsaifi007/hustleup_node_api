-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2017 at 08:33 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hustle_up`
--

-- --------------------------------------------------------

--
-- Table structure for table `ht_aclpermission`
--

CREATE TABLE `ht_aclpermission` (
  `id` int(11) NOT NULL,
  `permKey` text NOT NULL,
  `permName` text NOT NULL,
  `permDescription` text NOT NULL,
  `permController` text NOT NULL,
  `permAction` text NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_aclpermission`
--

INSERT INTO `ht_aclpermission` (`id`, `permKey`, `permName`, `permDescription`, `permController`, `permAction`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'list_schools', 'List Schools', '', 'Schools', 'index', '1', '2017-07-18 00:29:49', '2017-07-17 22:30:00'),
(2, 'add_schools', 'Add Schools', '', 'Schools', 'add', '1', '2017-07-18 00:29:49', '2017-07-17 22:30:00'),
(3, 'edit_schools', 'Edit Schools', '', 'Schools', 'edit', '1', '2017-07-18 00:33:27', '2017-07-17 22:30:00'),
(4, 'delete_schools', 'Delete Schools', '', 'Schools', 'delete', '1', '2017-07-18 00:33:27', '2017-07-17 22:30:00'),
(5, 'status_schools', 'Status Schools', '', 'Schools', 'status', '1', '2017-07-18 00:35:35', '2017-07-17 22:30:00'),
(10, 'list_superadminusers', 'List Superadmin', '', 'Superadminusers', 'index', '1', '2017-07-25 06:58:53', '2017-07-24 13:00:00'),
(11, 'add_superadminusers', 'Add Superadmin', '', 'Superadminusers', 'add', '1', '2017-07-25 06:58:53', '2017-07-24 13:00:00'),
(12, 'edit_superadminusers', 'Edit Superadmin', '', 'Superadminusers', 'edit', '1', '2017-07-25 07:00:12', '2017-07-24 13:00:00'),
(13, 'delete_superadminusers', 'Delete Superadmin', '', 'Superadminusers', 'delete', '1', '2017-07-25 07:00:12', '2017-07-24 13:00:00'),
(14, 'status_superadminusers', 'Status Superadmin', '', 'Superadminusers', 'status', '1', '2017-07-25 07:00:55', '2017-07-24 13:00:00'),
(15, 'list_headcoachusers', 'List Headcoach Users', '', 'Headcoachusers', 'index', '1', '2017-07-25 07:07:49', '2017-07-24 13:00:00'),
(16, 'add_headcoachusers', 'Add Headcoach Users', '', 'Headcoachusers', 'add', '1', '2017-07-25 07:07:49', '2017-07-24 13:00:00'),
(17, 'edit_headcoachusers', 'Edit Headcoachusers', '', 'Headcoachusers', 'edit', '1', '2017-07-25 07:11:56', '2017-07-24 13:00:00'),
(18, 'delete_headcoachusers', 'Delete Headcoachusers', '', 'Headcoachusers', 'delete', '1', '2017-07-25 07:11:56', '2017-07-24 13:00:00'),
(19, 'status_headcoachusers', 'Status Headcoachusers', '', 'Headcoachusers', 'status', '1', '2017-07-25 07:12:39', '2017-07-24 13:00:00'),
(20, 'list_coachusers', 'List Coachusers', '', 'Coachusers', 'index', '1', '2017-07-25 07:17:39', '2017-07-24 13:00:00'),
(21, 'add_coachusers', 'Add Coachusers', '', 'Coachusers', 'add', '1', '2017-07-25 07:17:39', '2017-07-24 13:00:00'),
(22, 'edit_coachusers', 'Edit Coachusers', '', 'Coachusers', 'edit', '1', '2017-07-25 07:18:57', '2017-07-24 13:00:00'),
(23, 'delete_coachusers', 'Delete Coachusers', '', 'Coachusers', 'delete', '1', '2017-07-25 07:18:57', '2017-07-24 13:00:00'),
(24, 'status_coachusers', 'Status Coachusers', '', 'Coachusers', 'status', '1', '2017-07-25 07:19:41', '2017-07-24 13:00:00'),
(25, 'list_playersusers', 'List Playerusers', '', 'playersusers', 'index', '1', '2017-07-25 08:54:52', '2017-07-24 13:00:00'),
(26, 'add_playersusers', 'Add Playerusers', '', 'playersusers', 'add', '1', '2017-07-25 08:54:52', '2017-07-24 13:00:00'),
(27, 'edit_playersusers', 'Edit Playerusers', '', 'playersusers', 'edit', '1', '2017-07-25 08:55:51', '2017-07-24 13:00:00'),
(28, 'delete_playersusers', 'Delete Playerusers', '', 'playersusers', 'delete', '1', '2017-07-25 08:55:51', '2017-07-24 13:00:00'),
(29, 'status_playersusers', 'Status Playerusers', '', 'playersusers', 'status', '1', '2017-07-25 08:56:22', '2017-07-24 13:00:00'),
(30, 'list_team', 'List Team', '', 'Team', 'index', '1', '2017-07-26 07:01:27', '2017-07-25 13:00:00'),
(31, 'add_team', 'Add Team', '', 'Team', 'add', '1', '2017-07-26 07:01:27', '2017-07-25 13:00:00'),
(32, 'edit_team', 'Edit Team', '', 'Team', 'edit', '1', '2017-07-26 07:02:30', '2017-07-25 13:00:00'),
(33, 'delete_team', 'Delete Team', '', 'Team', 'delete', '1', '2017-07-26 07:02:30', '2017-07-25 13:00:00'),
(34, 'status_team', 'Status Team', '', 'Team', 'status', '1', '2017-07-26 07:03:38', '2017-07-25 13:00:00'),
(36, 'edit_roles', 'Edit Roles', '', 'Roles', 'Edit', '1', '2017-08-02 01:06:43', '2017-08-01 13:00:00'),
(37, 'list_roles', 'List Roles', '', 'Roles', 'Index', '1', '2017-08-02 01:24:28', '2017-08-01 13:00:00'),
(38, 'edit_roles', 'Edit Roles', '', 'Roles', 'Edit', '1', '2017-08-02 01:24:28', '2017-08-01 13:00:00'),
(39, 'list_permissions', 'List Permissions', '', 'Permissions', 'index', '1', '2017-08-04 00:21:17', '2017-08-03 13:00:00'),
(40, 'edit_permissions', 'Edit Permissions', '', 'Permissions', 'Edit', '1', '2017-08-04 00:21:17', '2017-08-03 13:00:00'),
(41, 'history_permissions', 'History Permissions', '', 'Permissions', 'History', '1', '2017-08-04 00:21:59', '2017-08-03 13:00:00'),
(42, 'list_parameter', 'List Parameter', '', 'Parameter', 'Index', '1', '2017-08-04 07:21:31', '2017-08-03 13:00:00'),
(43, 'add_parameter', 'Add Parameter', '', 'Parameter', 'Add', '1', '2017-08-04 07:21:31', '2017-08-03 13:00:00'),
(44, 'edit_parameter', 'Edit Parameter', '', 'Parameter', 'Edit', '1', '2017-08-04 07:22:43', '2017-08-03 13:00:00'),
(45, 'delete_parameter', 'Delete Parameter', '', 'Parameter', 'Delete', '1', '2017-08-04 07:22:43', '2017-08-03 13:00:00'),
(46, 'history_parameter', 'History Parameter', '', 'Parameter', 'History', '1', '2017-08-04 07:23:53', '2017-08-03 13:00:00'),
(47, 'status_parameter', 'Status Parameter', '', 'Parameter', 'Status', '1', '2017-08-04 07:23:53', '2017-08-03 13:00:00'),
(48, 'list_subscription', 'List Subscription', '', 'Subscription', 'Index', '1', '2017-08-04 07:24:55', '2017-08-03 13:00:00'),
(49, 'add_subscription', 'Add Subscription', '', 'Subscription', 'Add', '1', '2017-08-04 07:24:55', '2017-08-03 13:00:00'),
(50, 'edit_subscription', 'Edit Subscription', '', 'Subscription', 'Edit', '1', '2017-08-04 07:26:02', '2017-08-03 13:00:00'),
(51, 'delete_subscription', 'Delete Subscription', '', 'Subscription', 'Delete', '1', '2017-08-04 07:26:02', '2017-08-03 13:00:00'),
(52, 'history_subscription', 'History Subscription', '', 'Subscription', 'History', '1', '2017-08-04 07:27:16', '2017-08-03 13:00:00'),
(53, 'status_subscription', 'Status Subscription', '', 'Subscription', 'Status', '1', '2017-08-04 07:27:16', '2017-08-03 13:00:00'),
(54, 'list_position', 'List Position', '', 'Position', 'Index', '1', '2017-08-08 01:09:28', '2017-08-07 13:00:00'),
(55, 'add_position', 'Add Position', '', 'Position', 'Add', '1', '2017-08-08 01:09:28', '2017-08-07 13:00:00'),
(56, 'edit_position', 'Edit Position', '', 'Position', 'Edit', '1', '2017-08-08 01:10:41', '2017-08-07 13:00:00'),
(57, 'delete_position', 'Delete Position', '', 'Position', 'Delete', '1', '2017-08-08 01:10:41', '2017-08-07 13:00:00'),
(58, 'history_position', 'History Position', '', 'Position', 'History', '1', '2017-08-08 01:12:00', '2017-08-07 13:00:00'),
(59, 'status_position', 'Status Position', '', 'Position', 'Status', '1', '2017-08-08 01:12:00', '2017-08-07 13:00:00'),
(60, 'list_rolespermissions', 'List Rolespermissions', '', 'Rolespermissions', 'index', '1', '2017-08-10 00:53:12', '2017-08-09 13:00:00'),
(61, 'add_rolespermissions', 'Add Rolespermissions', '', 'Rolespermissions', 'Add', '1', '2017-08-10 00:53:12', '2017-08-09 13:00:00'),
(62, 'edit_rolespermissions', 'Edit Rolespermissions', '', 'Rolespermissions', 'Edit', '1', '2017-08-10 01:02:41', '2017-08-09 13:00:00'),
(63, 'delete_rolespermissions', 'Delete Rolespermissions', '', 'Rolespermissions', 'Delete', '1', '2017-08-10 01:02:41', '2017-08-09 13:00:00'),
(64, 'history_rolespermissions', 'History Rolespermissions', '', 'Rolespermissions', 'History', '1', '2017-08-10 01:04:53', '2017-08-09 13:00:00'),
(66, 'status_rolespermissions', 'Status Rolespermissions', '', 'Rolespermissions', 'Status', '1', '2017-08-16 07:31:29', '2017-08-15 13:00:00'),
(67, 'list_players_position', 'List Players Position', '', 'Players_position', 'index', '1', '2017-10-03 11:35:53', '0000-00-00 00:00:00'),
(68, 'add_players_position', 'Add Players position', '', 'Players_position', 'Add', '1', '2017-10-03 11:39:06', '0000-00-00 00:00:00'),
(69, 'edit_players_position', 'Edit Players position', '', 'Players_position', 'Edit', '1', '2017-10-03 11:39:06', '0000-00-00 00:00:00'),
(70, 'delete_players_position', 'Delete Players Position', '', 'Players_position', 'Delete', '1', '2017-10-03 11:42:06', '0000-00-00 00:00:00'),
(71, 'history_players_position', 'History Players Position', '', 'Players_position', 'History', '1', '2017-10-03 11:42:06', '0000-00-00 00:00:00'),
(72, 'list_season', 'List Season', '', 'Seasons', 'index', '1', '2017-10-31 04:28:02', '0000-00-00 00:00:00'),
(73, 'add_season', 'Add season', '', 'Seasons', 'add', '1', '2017-10-31 04:28:02', '0000-00-00 00:00:00'),
(74, 'edit_season', 'Edit Season', '', 'Seasons', 'edit', '1', '2017-10-31 04:30:17', '0000-00-00 00:00:00'),
(75, 'delete_season', 'Delete season', '', 'Seasons', 'delete', '1', '2017-10-31 04:30:17', '0000-00-00 00:00:00'),
(76, 'status_season', 'Status Season', '', 'Seasons', 'status', '1', '2017-10-31 04:31:12', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_aclrolepermission`
--

CREATE TABLE `ht_aclrolepermission` (
  `id` int(11) NOT NULL,
  `roleId` int(11) DEFAULT NULL,
  `permID` int(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_aclrolepermission`
--

INSERT INTO `ht_aclrolepermission` (`id`, `roleId`, `permID`, `status`, `createdAt`, `updatedAt`) VALUES
(120, 2, 2, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(121, 2, 3, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(122, 2, 4, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(123, 2, 5, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(124, 2, 20, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(125, 2, 21, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(126, 2, 22, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(127, 2, 23, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(128, 2, 24, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(129, 2, 25, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(130, 2, 26, '1', '2017-09-05 01:46:46', '0000-00-00 00:00:00'),
(131, 2, 27, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(132, 2, 28, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(133, 2, 29, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(134, 2, 30, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(135, 2, 31, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(136, 2, 32, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(137, 2, 33, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(138, 2, 34, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(139, 2, 42, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(140, 2, 43, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(141, 2, 44, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(142, 2, 45, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(143, 2, 46, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(144, 2, 47, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(145, 2, 48, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(146, 2, 49, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(147, 2, 50, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(148, 2, 51, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(149, 2, 52, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(150, 2, 53, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(151, 2, 54, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(152, 2, 55, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(153, 2, 56, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(154, 2, 57, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(155, 2, 58, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(156, 2, 59, '1', '2017-09-05 01:46:47', '0000-00-00 00:00:00'),
(203, 1, 1, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(204, 1, 2, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(205, 1, 3, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(206, 1, 4, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(207, 1, 5, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(208, 1, 10, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(209, 1, 11, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(210, 1, 12, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(211, 1, 13, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(212, 1, 14, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(213, 1, 15, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(214, 1, 16, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(215, 1, 17, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(216, 1, 18, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(217, 1, 19, '1', '2017-10-27 11:26:00', '0000-00-00 00:00:00'),
(218, 1, 20, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(219, 1, 21, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(220, 1, 22, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(221, 1, 23, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(222, 1, 24, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(223, 1, 25, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(224, 1, 26, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(225, 1, 27, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(226, 1, 28, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(227, 1, 29, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(228, 1, 30, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(229, 1, 31, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(230, 1, 32, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(231, 1, 33, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(232, 1, 34, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(233, 1, 36, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(234, 1, 37, '1', '2017-10-27 11:26:01', '0000-00-00 00:00:00'),
(235, 1, 38, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(236, 1, 39, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(237, 1, 40, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(238, 1, 41, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(239, 1, 42, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(240, 1, 43, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(241, 1, 44, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(242, 1, 45, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(243, 1, 46, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(244, 1, 47, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(245, 1, 48, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(246, 1, 49, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(247, 1, 50, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(248, 1, 51, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(249, 1, 52, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(250, 1, 53, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(251, 1, 54, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(252, 1, 55, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(253, 1, 56, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(254, 1, 57, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(255, 1, 58, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(256, 1, 59, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(257, 1, 60, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(258, 1, 61, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(259, 1, 62, '1', '2017-10-27 11:26:02', '0000-00-00 00:00:00'),
(260, 1, 63, '1', '2017-10-27 11:26:03', '0000-00-00 00:00:00'),
(261, 1, 64, '1', '2017-10-27 11:26:03', '0000-00-00 00:00:00'),
(262, 1, 66, '1', '2017-10-27 11:26:03', '0000-00-00 00:00:00'),
(263, 1, 67, '1', '2017-10-27 11:26:03', '0000-00-00 00:00:00'),
(264, 1, 68, '1', '2017-10-27 11:26:03', '0000-00-00 00:00:00'),
(265, 1, 69, '1', '2017-10-27 11:26:03', '0000-00-00 00:00:00'),
(266, 1, 70, '1', '2017-10-27 11:26:03', '0000-00-00 00:00:00'),
(267, 1, 71, '1', '2017-10-27 11:26:03', '0000-00-00 00:00:00'),
(273, 3, 25, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(274, 3, 26, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(275, 3, 27, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(276, 3, 28, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(277, 3, 29, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(278, 3, 30, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(279, 3, 31, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(280, 3, 32, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(281, 3, 33, '1', '2017-10-31 04:36:46', '0000-00-00 00:00:00'),
(282, 3, 34, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(283, 3, 67, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(284, 3, 68, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(285, 3, 69, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(286, 3, 70, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(287, 3, 71, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(288, 3, 72, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(289, 3, 73, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(290, 3, 74, '1', '2017-10-31 04:36:47', '0000-00-00 00:00:00'),
(291, 3, 75, '1', '2017-10-31 04:36:48', '0000-00-00 00:00:00'),
(292, 3, 76, '1', '2017-10-31 04:36:48', '0000-00-00 00:00:00'),
(303, 4, 72, '1', '2017-11-01 06:33:08', '0000-00-00 00:00:00'),
(304, 4, 73, '1', '2017-11-01 06:33:08', '0000-00-00 00:00:00'),
(305, 4, 74, '1', '2017-11-01 06:33:08', '0000-00-00 00:00:00'),
(306, 4, 75, '1', '2017-11-01 06:33:08', '0000-00-00 00:00:00'),
(307, 4, 76, '1', '2017-11-01 06:33:08', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_aclroles`
--

CREATE TABLE `ht_aclroles` (
  `id` int(11) NOT NULL COMMENT 'Auto Increment Id',
  `roleName` varchar(255) NOT NULL COMMENT 'Set Role Name Here',
  `roleSlug` varchar(255) NOT NULL,
  `roleDescription` text NOT NULL,
  `status` enum('0','1') NOT NULL COMMENT 'Set Status Active / Inactive',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_aclroles`
--

INSERT INTO `ht_aclroles` (`id`, `roleName`, `roleSlug`, `roleDescription`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'SuperAdmin', 'superadmin', 'Super admin can control all the modules for hustleup and assign permission to different - 02 headcoach , coach , players as well', '1', '2017-07-17 07:00:00', '0000-00-00 00:00:00'),
(2, 'HeadCoach', 'headcoach', 'Headcoach can control all coaches modules , players , teams as well', '1', '2017-07-17 07:00:00', '0000-00-00 00:00:00'),
(3, 'Coach', 'coach', 'Coach can control all players ', '1', '2017-07-17 07:01:36', '0000-00-00 00:00:00'),
(4, 'Player', 'player', 'Player can view his modules', '1', '2017-09-04 06:43:03', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_cities`
--

CREATE TABLE `ht_cities` (
  `id` int(11) NOT NULL,
  `cityName` varchar(255) NOT NULL,
  `stateId` int(11) DEFAULT NULL,
  `countryId` int(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_countries`
--

CREATE TABLE `ht_countries` (
  `id` int(11) NOT NULL,
  `countryName` varchar(255) NOT NULL,
  `countryISOCode` varchar(2) NOT NULL,
  `countryISDCode` varchar(7) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_coupon`
--

CREATE TABLE `ht_coupon` (
  `id` int(11) NOT NULL,
  `couponCode` text NOT NULL,
  `startDate` date NOT NULL,
  `expiryDate` date NOT NULL,
  `used` enum('0','1') NOT NULL,
  `discount` float(10,2) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_invoice`
--

CREATE TABLE `ht_invoice` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `invoiceNo` int(11) NOT NULL,
  `invoiceDate` datetime NOT NULL,
  `invoiceAmount` decimal(6,2) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_invoice_payment`
--

CREATE TABLE `ht_invoice_payment` (
  `id` int(11) NOT NULL,
  `invoiceId` int(11) DEFAULT NULL,
  `amountReceived` decimal(6,2) NOT NULL,
  `amountSent` decimal(6,2) NOT NULL,
  `dateReceived` datetime NOT NULL,
  `dateSent` datetime NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_order`
--

CREATE TABLE `ht_order` (
  `id` int(11) NOT NULL COMMENT 'Set Auto Increment Id Here',
  `userId` int(11) DEFAULT NULL COMMENT 'Set userId here',
  `totalCost` decimal(6,2) NOT NULL COMMENT 'Set Total Cost Here',
  `orderDate` datetime NOT NULL COMMENT 'Set Order Date Here',
  `status` enum('0','1') NOT NULL COMMENT 'Set Status Here',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Set Created Date Here',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Set Updated Date Here'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_parameter_master`
--

CREATE TABLE `ht_parameter_master` (
  `id` int(11) NOT NULL,
  `parameterTitle` text NOT NULL,
  `parameterDescription` text NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_parameter_master`
--

INSERT INTO `ht_parameter_master` (`id`, `parameterTitle`, `parameterDescription`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Offence', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '1', '2017-08-08 03:29:21', '0000-00-00 00:00:00'),
(2, 'Defense', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '1', '2017-08-08 03:30:56', '0000-00-00 00:00:00'),
(4, 'Special Teams', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '1', '2017-08-08 03:50:19', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_players_notes`
--

CREATE TABLE `ht_players_notes` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `coach_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `notes` text NOT NULL,
  `created_on` date NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_players_notes`
--

INSERT INTO `ht_players_notes` (`id`, `coach_id`, `player_id`, `notes`, `created_on`, `modified_on`) VALUES
(1, 51, 55, 'This is first test message', '2017-10-27', '2017-10-27 16:20:18'),
(2, 51, 55, '&lt;h4&gt;&lt;span style=&quot;font-weight: bold; text-decoration-line: underline; color: rgb(255, 156, 0);&quot;&gt;This is the second message&lt;/span&gt;&lt;/h4&gt;', '2017-10-25', '2017-10-27 16:21:54'),
(3, 51, 55, '&lt;ol&gt;&lt;li&gt;&lt;span style=&quot;background-color: rgb(0, 0, 0); color: rgb(247, 247, 247);&quot;&gt;This is the Third message&amp;nbsp;&lt;/span&gt;&lt;br&gt;&lt;/li&gt;&lt;/ol&gt;', '2017-10-25', '2017-10-27 16:22:44'),
(4, 51, 55, '&lt;h3&gt;&lt;span style=&quot;background-color: rgb(255, 255, 0);&quot;&gt;This is the fourth message&amp;nbsp;&lt;/span&gt;&lt;/h3&gt;', '2017-10-24', '2017-10-27 16:23:19'),
(5, 51, 55, '&lt;h5&gt;&lt;ul&gt;&lt;li&gt;&lt;span style=&quot;color: rgb(255, 0, 0);&quot;&gt;This is fifth test message&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/h5&gt;', '2017-10-22', '2017-10-27 16:23:54'),
(6, 1, 55, 'test', '2017-10-27', '2017-10-27 17:18:40'),
(7, 1, 36, 'fdsf', '2017-10-27', '2017-10-27 17:18:50');

-- --------------------------------------------------------

--
-- Table structure for table `ht_players_rating`
--

CREATE TABLE `ht_players_rating` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'coach_id',
  `player_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `player_rating` tinyint(1) NOT NULL,
  `created_at` date NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_players_rating`
--

INSERT INTO `ht_players_rating` (`id`, `user_id`, `player_id`, `position_id`, `player_rating`, `created_at`, `modified_on`) VALUES
(1, 51, 94, 19, 3, '2017-10-25', '2017-10-27 09:44:45'),
(2, 51, 94, 22, 3, '2017-10-27', '2017-10-27 09:44:57'),
(3, 51, 94, 1, 5, '2017-10-27', '2017-10-27 09:45:03'),
(4, 51, 94, 19, 2, '2017-10-27', '2017-10-27 09:45:22'),
(5, 51, 95, 19, 2, '2017-10-26', '2017-10-27 10:09:37'),
(6, 51, 95, 21, 2, '2017-10-27', '2017-10-27 10:09:43'),
(7, 51, 95, 13, 1, '2017-10-26', '2017-10-27 16:25:21'),
(8, 51, 95, 13, 3, '2017-10-25', '2017-10-27 16:26:03'),
(9, 51, 95, 13, 3, '2017-10-27', '2017-10-27 16:26:24'),
(10, 51, 95, 18, 2, '2017-10-27', '2017-10-27 16:36:57'),
(11, 51, 95, 9, 3, '2017-10-27', '2017-10-27 18:25:00'),
(12, 51, 95, 19, 5, '2017-10-30', '2017-10-30 10:01:23'),
(13, 51, 95, 22, 2, '2017-10-30', '2017-10-30 16:02:27'),
(15, 51, 95, 6, 2, '2017-10-30', '2017-10-30 17:30:02');

-- --------------------------------------------------------

--
-- Table structure for table `ht_position_master`
--

CREATE TABLE `ht_position_master` (
  `id` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `parameterId` int(11) DEFAULT NULL,
  `positionTitle` text NOT NULL,
  `positionDescription` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_position_master`
--

INSERT INTO `ht_position_master` (`id`, `parentId`, `parameterId`, `positionTitle`, `positionDescription`, `status`, `createdAt`, `updatedAt`) VALUES
(1, NULL, 1, 'Quarterback', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 1, '2017-08-08 05:23:39', '2017-08-07 13:00:00'),
(5, NULL, 1, 'Running back', '', 1, '2017-08-08 08:31:15', '2017-08-07 13:00:00'),
(6, NULL, 1, 'Full back', '', 1, '2017-08-08 08:31:15', '2017-08-07 13:00:00'),
(7, NULL, 1, 'Wide receiver', '', 1, '2017-08-08 08:31:51', '2017-08-07 13:00:00'),
(8, NULL, 1, 'Left/right tackle', '', 1, '2017-08-08 08:31:51', '2017-08-07 13:00:00'),
(9, NULL, 1, 'Left/Right guard', '', 1, '2017-08-08 08:32:48', '2017-08-07 13:00:00'),
(10, NULL, 1, 'Center', '', 1, '2017-08-08 08:32:48', '2017-08-07 13:00:00'),
(11, NULL, 1, 'Tight end', '', 1, '2017-08-08 08:41:34', '2017-08-07 13:00:00'),
(12, NULL, 2, 'Left/right cornerback', '', 1, '2017-08-08 08:42:19', '2017-08-07 13:00:00'),
(13, NULL, 2, 'Left Outside/Middle Linebacker', '', 1, '2017-08-08 08:42:19', '2017-08-07 13:00:00'),
(14, NULL, 2, 'Defensive Left/Right End', '', 1, '2017-08-08 08:42:47', '2017-08-07 13:00:00'),
(15, NULL, 2, 'Left/Right Tackle', '', 1, '2017-08-08 08:42:47', '2017-08-07 13:00:00'),
(16, NULL, 2, 'Safety', '', 1, '2017-08-08 08:43:24', '2017-08-07 13:00:00'),
(17, NULL, 4, 'Kicker', '', 1, '2017-08-08 08:44:07', '2017-08-07 13:00:00'),
(18, NULL, 4, 'Long snapper', '', 1, '2017-08-08 08:44:07', '2017-08-07 13:00:00'),
(19, NULL, 4, 'Punter', '', 1, '2017-08-08 08:44:42', '2017-08-07 13:00:00'),
(20, NULL, 2, 'Kickoff specialist', '', 1, '2017-08-08 08:44:42', '2017-08-07 13:00:00'),
(21, NULL, 4, 'Punt/kick returner', '', 1, '2017-08-08 08:45:08', '2017-08-07 13:00:00'),
(22, NULL, 4, 'Gunner', '', 1, '2017-08-08 08:45:08', '2017-08-07 13:00:00'),
(29, 29, 4, 'Jammer', '', 1, '2017-08-08 08:45:57', '2017-08-07 13:00:00'),
(30, 1, 1, 'Accuracy', '', 1, '2017-08-08 08:46:26', '0000-00-00 00:00:00'),
(31, 1, 1, 'Arm strength', '', 1, '2017-08-08 08:46:40', '0000-00-00 00:00:00'),
(32, 1, 1, 'Ball security', '', 1, '2017-08-08 08:46:51', '0000-00-00 00:00:00'),
(33, 11, 4, 'Test', '', 1, '2017-09-14 07:01:40', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_position_parameter_child_rating_set`
--

CREATE TABLE `ht_position_parameter_child_rating_set` (
  `id` int(11) NOT NULL,
  `parameterId` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `positionId` int(11) DEFAULT NULL,
  `teamId` int(11) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_position_parameter_child_rating_set1`
--

CREATE TABLE `ht_position_parameter_child_rating_set1` (
  `id` int(11) NOT NULL,
  `parameterId` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `positionId` int(11) DEFAULT NULL,
  `teamId` int(11) DEFAULT NULL,
  `rating` float(10,2) NOT NULL,
  `avgRating` float(10,2) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_position_parameter_child_rating_set1`
--

INSERT INTO `ht_position_parameter_child_rating_set1` (`id`, `parameterId`, `role_id`, `userId`, `positionId`, `teamId`, `rating`, `avgRating`, `status`, `createdAt`, `updatedAt`) VALUES
(204, 2, 1, 1, 1, 12, 0.00, 0.00, '1', '2017-09-13 23:21:09', '0000-00-00 00:00:00'),
(205, 2, 1, 1, 5, 12, 0.00, 0.00, '1', '2017-09-13 23:21:09', '0000-00-00 00:00:00'),
(206, 2, 1, 1, 8, 12, 0.00, 0.00, '1', '2017-09-13 23:21:09', '0000-00-00 00:00:00'),
(207, 2, 1, 1, 15, 12, 0.00, 0.00, '1', '2017-09-13 23:21:09', '0000-00-00 00:00:00'),
(208, 2, 1, 1, 19, 12, 0.00, 0.00, '1', '2017-09-13 23:21:09', '0000-00-00 00:00:00'),
(263, 1, 1, 1, 1, 7, 0.00, 0.00, '1', '2017-09-19 07:12:21', '0000-00-00 00:00:00'),
(264, 1, 1, 1, 30, 7, 0.00, 0.00, '1', '2017-09-19 07:12:22', '0000-00-00 00:00:00'),
(265, 1, 1, 1, 31, 7, 0.00, 0.00, '1', '2017-09-19 07:12:22', '0000-00-00 00:00:00'),
(266, 1, 1, 1, 32, 7, 0.00, 0.00, '1', '2017-09-19 07:12:22', '0000-00-00 00:00:00'),
(278, 2, 1, 1, 1, 35, 0.00, 0.00, '1', '2017-09-20 02:18:36', '0000-00-00 00:00:00'),
(279, 2, 1, 1, 6, 35, 0.00, 0.00, '1', '2017-09-20 02:18:36', '0000-00-00 00:00:00'),
(280, 2, 1, 1, 7, 35, 0.00, 0.00, '1', '2017-09-20 02:18:36', '0000-00-00 00:00:00'),
(281, 2, 1, 1, 1, 36, 0.00, 0.00, '1', '2017-09-20 03:07:33', '0000-00-00 00:00:00'),
(282, 2, 1, 1, 5, 36, 0.00, 0.00, '1', '2017-09-20 03:07:33', '0000-00-00 00:00:00'),
(283, 2, 1, 1, 6, 36, 0.00, 0.00, '1', '2017-09-20 03:07:33', '0000-00-00 00:00:00'),
(287, 1, 1, 1, 1, 37, 0.00, 0.00, '1', '2017-09-20 05:19:10', '0000-00-00 00:00:00'),
(288, 1, 1, 1, 32, 37, 0.00, 0.00, '1', '2017-09-20 05:19:10', '0000-00-00 00:00:00'),
(289, 1, 1, 1, 6, 37, 0.00, 0.00, '1', '2017-09-20 05:19:10', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_position_team_mapping`
--

CREATE TABLE `ht_position_team_mapping` (
  `id` int(11) NOT NULL,
  `positionId` int(11) DEFAULT NULL,
  `teamId` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_position_team_mapping`
--

INSERT INTO `ht_position_team_mapping` (`id`, `positionId`, `teamId`, `status`, `createdAt`, `updatedAt`) VALUES
(215, 32, 5, 1, '2017-10-25 11:41:21', '0000-00-00 00:00:00'),
(216, 5, 5, 1, '2017-10-25 11:41:21', '0000-00-00 00:00:00'),
(217, 6, 5, 1, '2017-10-25 11:41:21', '0000-00-00 00:00:00'),
(218, 14, 6, 1, '2017-10-25 11:46:46', '0000-00-00 00:00:00'),
(219, 15, 6, 1, '2017-10-25 11:46:47', '0000-00-00 00:00:00'),
(220, 20, 6, 1, '2017-10-25 11:46:47', '0000-00-00 00:00:00'),
(221, 14, 7, 1, '2017-10-25 12:03:10', '0000-00-00 00:00:00'),
(222, 15, 7, 1, '2017-10-25 12:03:10', '0000-00-00 00:00:00'),
(223, 16, 7, 1, '2017-10-25 12:03:10', '0000-00-00 00:00:00'),
(224, 17, 8, 1, '2017-10-26 04:53:09', '0000-00-00 00:00:00'),
(225, 18, 8, 1, '2017-10-26 04:53:09', '0000-00-00 00:00:00'),
(226, 19, 8, 1, '2017-10-26 04:53:09', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_school`
--

CREATE TABLE `ht_school` (
  `id` int(11) NOT NULL,
  `schoolName` varchar(255) NOT NULL,
  `schoolCode` text NOT NULL,
  `countryId` int(11) DEFAULT NULL,
  `stateId` int(11) DEFAULT NULL,
  `cityId` int(11) DEFAULT NULL,
  `zipcodeId` int(11) DEFAULT NULL,
  `profile` text NOT NULL,
  `profileURL` text NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_school`
--

INSERT INTO `ht_school` (`id`, `schoolName`, `schoolCode`, `countryId`, `stateId`, `cityId`, `zipcodeId`, `profile`, `profileURL`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Dav School', 'Dav-code456', NULL, NULL, NULL, NULL, '', '', '1', '2017-07-24 05:41:43', '2017-07-23 13:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_season_category`
--

CREATE TABLE `ht_season_category` (
  `id` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `season_name` varchar(255) NOT NULL,
  `season_description` text NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_season_category`
--

INSERT INTO `ht_season_category` (`id`, `parentId`, `season_name`, `season_description`, `status`, `createdAt`, `updatedAt`) VALUES
(2, NULL, 'Season 1234', 'Season 100', 1, '2017-10-31 07:49:59', '0000-00-00 00:00:00'),
(3, NULL, 'Season ', 'Season ', 1, '2017-10-31 07:50:56', '0000-00-00 00:00:00'),
(4, NULL, 'Season-2', 'Season-2', 1, '2017-10-31 09:18:52', '0000-00-00 00:00:00'),
(5, NULL, 'Season 44', 'Season 44', 1, '2017-10-31 10:40:54', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_season_category_type_set`
--

CREATE TABLE `ht_season_category_type_set` (
  `id` int(11) NOT NULL,
  `seasonId` int(11) DEFAULT NULL,
  `teamId` int(11) DEFAULT NULL,
  `roleId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_season_category_type_set`
--

INSERT INTO `ht_season_category_type_set` (`id`, `seasonId`, `teamId`, `roleId`, `userId`, `status`, `createdAt`, `updatedAt`) VALUES
(47, 2, 8, 3, 51, 1, '2017-10-31 11:13:13', '0000-00-00 00:00:00'),
(57, 5, 5, 3, 51, 1, '2017-10-31 13:01:03', '0000-00-00 00:00:00'),
(58, 4, 5, 3, 51, 1, '2017-10-31 13:13:59', '0000-00-00 00:00:00'),
(59, 4, 6, 3, 51, 1, '2017-10-31 13:13:59', '0000-00-00 00:00:00'),
(60, 4, 7, 3, 51, 1, '2017-10-31 13:13:59', '0000-00-00 00:00:00'),
(61, 3, 5, 3, 51, 1, '2017-10-31 13:14:04', '0000-00-00 00:00:00'),
(62, 3, 6, 3, 51, 1, '2017-10-31 13:14:04', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_state`
--

CREATE TABLE `ht_state` (
  `id` int(11) NOT NULL,
  `countryId` int(11) DEFAULT NULL,
  `stateName` varchar(255) NOT NULL,
  `stateAbbr` varchar(8) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_subscription_configuration_manager`
--

CREATE TABLE `ht_subscription_configuration_manager` (
  `id` int(11) NOT NULL,
  `subscriptionId` int(11) DEFAULT NULL,
  `configurationId` int(11) DEFAULT NULL,
  `couponId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_subscription_configuration_master`
--

CREATE TABLE `ht_subscription_configuration_master` (
  `id` int(11) NOT NULL COMMENT 'Set Auto Increment value',
  `configurationName` text NOT NULL COMMENT 'Set Configuration name here',
  `configurationValue` text NOT NULL COMMENT 'Set Configuration Value here',
  `status` enum('0','1') NOT NULL COMMENT 'Set Configuration status here',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set configuration created at here',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'set configuration updated at here'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_subscription_master`
--

CREATE TABLE `ht_subscription_master` (
  `id` int(11) NOT NULL COMMENT 'Set Auto Increment Id',
  `subscriptionName` varchar(255) NOT NULL COMMENT 'Set Subscription Name here',
  `subscriptionDescription` text NOT NULL COMMENT 'Set Subscription Description Here',
  `subscriptionPackagePrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Set Subscription Price here',
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Subscription Start Time',
  `duration_seconds` int(11) NOT NULL COMMENT 'Subscription Duration',
  `status` enum('0','1') NOT NULL COMMENT 'set Subscription Status Here',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Set Subscription Created At here',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Set Subscription Updated At here'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_subscription_master`
--

INSERT INTO `ht_subscription_master` (`id`, `subscriptionName`, `subscriptionDescription`, `subscriptionPackagePrice`, `start_time`, `duration_seconds`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Gold', '-Add 10 coaches\r\n-Can add 30 player logins\r\n-15 sec video storage\r\n-5 notes storage per coach per player\r\n-x gig for video & note storage\r\n', 200.00, '2017-08-30 04:27:44', 186500, '1', '2017-08-30 04:27:44', '2017-08-29 22:30:00'),
(2, 'Platinum', '-Add 30 coaches\r\n-Can add 60 player logins\r\n-30 sec video storage\r\n-15 notes storage per coach per player\r\n-x gig for video & note storage', 150.00, '2017-08-30 04:28:46', 186500, '1', '2017-08-30 04:28:46', '2017-08-29 22:30:00'),
(3, 'Diamond', '-Add unlimited amount of coaches\r\n-Add unlimited player logins\r\n-Determine cut/keep parameters\r\n-Remove & add different skills (cut keep parameters) \r\n-X gig Video & note Storage\r\n-60 sec video', 150.00, '2017-08-30 04:29:28', 186500, '1', '2017-08-30 04:29:28', '2017-08-29 22:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_team_registration`
--

CREATE TABLE `ht_team_registration` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `profile` text NOT NULL,
  `profileURL` text NOT NULL,
  `coach_email` varchar(50) NOT NULL,
  `primaryEmail` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_team_registration`
--

INSERT INTO `ht_team_registration` (`id`, `userId`, `title`, `description`, `profile`, `profileURL`, `coach_email`, `primaryEmail`, `password`, `status`, `createdAt`, `updatedAt`) VALUES
(5, 3, 'BPL', 'BPL', '', 'http://localhost:81/hestleup/uploads/team/', '', 'bpl@email.com', 'b805d03f09f1a53874456d7b40061d467f97a705', '1', '2017-10-25 11:24:35', '0000-00-00 00:00:00'),
(6, 3, 'CPL', 'CPL', 'feature.jpg', 'http://localhost:81/hestleup/uploads/team/feature.jpg', '', 'cpl@email.com', '6c5cb7bc3a8b3312fc1d939d5e4a2a88e76e2b71', '1', '2017-10-25 11:46:43', '0000-00-00 00:00:00'),
(7, 3, 'IPL', 'IPL', 'feature.jpg', 'http://localhost:81/hestleup/uploads/team/feature.jpg', '', 'ipl@email.com', 'ae6c10632361a02befc2746ea5fe32dcb445f82a', '1', '2017-10-25 12:03:00', '0000-00-00 00:00:00'),
(8, 3, 'PPL', 'PPL', 'feature.jpg', 'http://localhost:81/hestleup/uploads/team/feature.jpg', '', 'ppl@email.com', '2657e1758ec66eb7a5ceea1babe2a22131ed15f4', '1', '2017-10-26 04:53:06', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_tokens`
--

CREATE TABLE `ht_tokens` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `token` varchar(255) NOT NULL,
  `tokenString` text NOT NULL,
  `tokenReason` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'set default creation time',
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ht_user_registration`
--

CREATE TABLE `ht_user_registration` (
  `id` int(11) NOT NULL,
  `subconfigId` int(11) DEFAULT NULL,
  `schoolId` int(11) DEFAULT NULL,
  `teamId` int(11) DEFAULT NULL,
  `roleId` int(11) DEFAULT NULL,
  `fName` varchar(255) NOT NULL,
  `lName` varchar(255) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `userName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `jersey_number` smallint(4) UNSIGNED DEFAULT NULL,
  `player_height` float(5,2) DEFAULT NULL,
  `player_weight` float(5,2) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `reset_password` varchar(255) NOT NULL,
  `facebookId` varchar(255) NOT NULL,
  `deviceType` text NOT NULL,
  `deviceToken` text NOT NULL,
  `resetpasswordkey` enum('0','1') NOT NULL,
  `profile` text NOT NULL,
  `profileURL` text NOT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_user_registration`
--

INSERT INTO `ht_user_registration` (`id`, `subconfigId`, `schoolId`, `teamId`, `roleId`, `fName`, `lName`, `parentId`, `userName`, `email`, `phone`, `jersey_number`, `player_height`, `player_weight`, `password`, `reset_password`, `facebookId`, `deviceType`, `deviceToken`, `resetpasswordkey`, `profile`, `profileURL`, `status`, `createdAt`, `updatedAt`) VALUES
(1, NULL, NULL, NULL, 1, 'admin', 'admin', NULL, 'admin', 'admin@hustleup.com', '', 0, 0.00, 0.00, 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', '0', '', 'http://localhost:8081/hestleup/uploads/users/superadminuser/', '1', '2017-07-24 05:02:06', '2017-07-23 13:00:00'),
(36, NULL, NULL, NULL, 4, 'abcd', 'khan', 19, 'abcd', 'danishff.khan@rnf.tech', '', 0, 0.00, 0.00, '9c42e54aba41a19e6b92b3f48d9d2b70', '', '', '', '', '0', '', 'http://localhost:81/hestleup/uploads/users/playersusers/', '1', '2017-10-03 10:22:21', '0000-00-00 00:00:00'),
(37, NULL, NULL, NULL, 4, 'javed', 'javed', 19, 'javed', 'javed@hustleup.com', '9999888811', 12, 3.00, 3.00, 'javed@hustleup.com', '', '', '', '', '0', '', 'http://localhost:81/hestleup/uploads/users/playersusers/', '1', '2017-10-03 10:23:02', '0000-00-00 00:00:00'),
(38, NULL, NULL, NULL, 4, 'aahil', 'khan', 19, 'aahil11', 'aahil11@email.com', '9999888811', 11, 11.00, 11.00, '6e73acb35b0e89aa56e9657a856ff65d', '', '', '', '', '0', 'img_2.jpg', 'http://localhost:81/hestleup/uploads/users/playersusers/img_2.jpg', '1', '2017-10-04 05:06:03', '0000-00-00 00:00:00'),
(49, NULL, NULL, 6, 3, '', '', NULL, '', 'coach@email.com', '', NULL, NULL, NULL, 'eda463c50b47860443e302a2ce12c907', '', '', '', '', '0', '', '', '0', '2017-10-25 11:46:47', '0000-00-00 00:00:00'),
(50, NULL, 1, 6, 2, 'harish', 'khan', NULL, 'harish', 'headcoach@gmail.com', '', NULL, NULL, NULL, 'cd00efba27e23d500ce01e23782345ec', '', '', '', '', '0', 'feature.jpg', 'http://localhost:81/hestleup/uploads/users/headcoachuser/feature.jpg', '1', '2017-10-25 11:54:19', '0000-00-00 00:00:00'),
(51, NULL, 1, 6, 3, 'harish', 'harish', 50, 'harish', 'coach@gmail.com', '', NULL, NULL, NULL, '43c3ec07dd8d34bd90d8ab063b6b8b90', '', '', '', '', '0', 'feature.jpg', 'http://localhost:81/hestleup/uploads/users/coachuser/feature.jpg', '1', '2017-10-25 11:54:49', '0000-00-00 00:00:00'),
(52, NULL, NULL, 7, 3, '', '', NULL, '', 'IPL@email.com', '', NULL, NULL, NULL, 'SwluOQVb7e', '', '', '', '', '0', '', '', '0', '2017-10-25 12:03:10', '0000-00-00 00:00:00'),
(54, NULL, NULL, NULL, 4, 'harish', 'khan', 51, 'harish', 'harishp@gmail.com', '1111111111', 11111, 6.50, 60.00, 'f9b79398114cfde54d7f1c4719eb7983', '', '', '', '', '0', 'feature.jpg', 'http://localhost:81/hestleup/uploads/users/playersusers/feature.jpg', '1', '2017-10-25 12:51:10', '0000-00-00 00:00:00'),
(55, NULL, NULL, NULL, 4, 'aamir', 'khan', 51, 'aamir', 'aamir@gmail.com', '28544669', 11, 6.90, 60.00, '7610c3d81478e5fba5d71e8fce6cdf08', '', '', '', '', '0', 'cleaning.jpg', 'http://localhost:81/hestleup/uploads/users/playersusers/cleaning.jpg', '1', '2017-10-25 12:54:40', '0000-00-00 00:00:00'),
(56, NULL, NULL, 8, 3, '', '', NULL, '', 'PPL@email.com', '', NULL, NULL, NULL, 'EqgpLdO4D1', '', '', '', '', '0', '', '', '0', '2017-10-26 04:53:09', '0000-00-00 00:00:00'),
(57, NULL, NULL, NULL, 4, 'Player', 'Player', 1, 'Player', 'player@gmail.com', '9999888811', 12, 12.00, 12.00, 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', '0', 'floating-investment.jpg', 'http://localhost:81/hestleup/uploads/users/playersusers/floating-investment.jpg', '1', '2017-11-01 05:58:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ht_user_team_mapping`
--

CREATE TABLE `ht_user_team_mapping` (
  `id` int(11) NOT NULL,
  `user_id` int(10) DEFAULT NULL COMMENT 'coach_id ,player_id',
  `position_id` int(10) DEFAULT NULL COMMENT 'position_team_mapping_id',
  `teams_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ht_user_team_mapping`
--

INSERT INTO `ht_user_team_mapping` (`id`, `user_id`, `position_id`, `teams_id`, `status`, `created_by`, `createdAt`, `updateAt`) VALUES
(88, 48, 215, 5, 0, 0, '2017-10-25 17:11:21', NULL),
(89, 37, 5, 5, 1, 0, '2017-10-25 17:13:53', NULL),
(90, 49, 220, 6, 0, 0, '2017-10-25 17:16:47', NULL),
(91, 52, 223, 7, 0, 0, '2017-10-25 17:33:11', NULL),
(92, 51, 223, 7, 0, 0, '2017-10-25 17:33:11', NULL),
(93, 37, 14, 7, 1, 0, '2017-10-25 17:36:01', NULL),
(94, 37, 15, 7, 1, 51, '2017-10-25 17:40:31', NULL),
(95, 36, 16, 7, 1, 51, '2017-10-25 17:42:10', NULL),
(96, 56, 226, 8, 0, NULL, '2017-10-26 10:23:10', NULL),
(97, 51, 226, 8, 0, NULL, '2017-10-26 10:23:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ht_zipcode`
--

CREATE TABLE `ht_zipcode` (
  `id` int(11) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `countryId` int(11) DEFAULT NULL,
  `stateId` int(11) DEFAULT NULL,
  `cityId` int(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ht_aclpermission`
--
ALTER TABLE `ht_aclpermission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ht_aclrolepermission`
--
ALTER TABLE `ht_aclrolepermission`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roleId` (`roleId`),
  ADD KEY `permID` (`permID`);

--
-- Indexes for table `ht_aclroles`
--
ALTER TABLE `ht_aclroles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ht_cities`
--
ALTER TABLE `ht_cities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stateId` (`stateId`),
  ADD KEY `countryId` (`countryId`);

--
-- Indexes for table `ht_countries`
--
ALTER TABLE `ht_countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ht_coupon`
--
ALTER TABLE `ht_coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ht_invoice`
--
ALTER TABLE `ht_invoice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `ht_invoice_payment`
--
ALTER TABLE `ht_invoice_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoiceId` (`invoiceId`);

--
-- Indexes for table `ht_order`
--
ALTER TABLE `ht_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `ht_parameter_master`
--
ALTER TABLE `ht_parameter_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ht_players_notes`
--
ALTER TABLE `ht_players_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `coach_id` (`coach_id`),
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `ht_players_rating`
--
ALTER TABLE `ht_players_rating`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `palyer_id` (`player_id`),
  ADD KEY `position_id` (`position_id`);

--
-- Indexes for table `ht_position_master`
--
ALTER TABLE `ht_position_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parentId` (`parentId`),
  ADD KEY `parameterId` (`parameterId`);

--
-- Indexes for table `ht_position_parameter_child_rating_set`
--
ALTER TABLE `ht_position_parameter_child_rating_set`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parameterId` (`parameterId`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `positionId` (`positionId`),
  ADD KEY `teamId` (`teamId`);

--
-- Indexes for table `ht_position_parameter_child_rating_set1`
--
ALTER TABLE `ht_position_parameter_child_rating_set1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parameterId` (`parameterId`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `positionId` (`positionId`),
  ADD KEY `teamId` (`teamId`);

--
-- Indexes for table `ht_position_team_mapping`
--
ALTER TABLE `ht_position_team_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `positionId` (`positionId`),
  ADD KEY `teamId` (`teamId`);

--
-- Indexes for table `ht_school`
--
ALTER TABLE `ht_school`
  ADD PRIMARY KEY (`id`),
  ADD KEY `countryId` (`countryId`),
  ADD KEY `stateId` (`stateId`),
  ADD KEY `cityId` (`cityId`),
  ADD KEY `zipcodeId` (`zipcodeId`);

--
-- Indexes for table `ht_season_category`
--
ALTER TABLE `ht_season_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parentId` (`parentId`);

--
-- Indexes for table `ht_season_category_type_set`
--
ALTER TABLE `ht_season_category_type_set`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `seasonId` (`seasonId`),
  ADD KEY `teamId` (`teamId`),
  ADD KEY `roleId` (`roleId`);

--
-- Indexes for table `ht_state`
--
ALTER TABLE `ht_state`
  ADD PRIMARY KEY (`id`),
  ADD KEY `countryId` (`countryId`);

--
-- Indexes for table `ht_subscription_configuration_manager`
--
ALTER TABLE `ht_subscription_configuration_manager`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscriptionId` (`subscriptionId`),
  ADD KEY `configurationId` (`configurationId`),
  ADD KEY `couponId` (`couponId`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `ht_subscription_configuration_master`
--
ALTER TABLE `ht_subscription_configuration_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ht_subscription_master`
--
ALTER TABLE `ht_subscription_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ht_team_registration`
--
ALTER TABLE `ht_team_registration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `ht_tokens`
--
ALTER TABLE `ht_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `ht_user_registration`
--
ALTER TABLE `ht_user_registration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subconfigId` (`subconfigId`),
  ADD KEY `schoolId` (`schoolId`),
  ADD KEY `teamId` (`teamId`),
  ADD KEY `roleId` (`roleId`),
  ADD KEY `parentId` (`parentId`);

--
-- Indexes for table `ht_user_team_mapping`
--
ALTER TABLE `ht_user_team_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teams_id` (`teams_id`),
  ADD KEY `position_id` (`position_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ht_zipcode`
--
ALTER TABLE `ht_zipcode`
  ADD PRIMARY KEY (`id`),
  ADD KEY `countryId` (`countryId`),
  ADD KEY `stateId` (`stateId`),
  ADD KEY `cityId` (`cityId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ht_aclpermission`
--
ALTER TABLE `ht_aclpermission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `ht_aclrolepermission`
--
ALTER TABLE `ht_aclrolepermission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=308;
--
-- AUTO_INCREMENT for table `ht_aclroles`
--
ALTER TABLE `ht_aclroles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Auto Increment Id', AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ht_cities`
--
ALTER TABLE `ht_cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_countries`
--
ALTER TABLE `ht_countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_coupon`
--
ALTER TABLE `ht_coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_invoice`
--
ALTER TABLE `ht_invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_invoice_payment`
--
ALTER TABLE `ht_invoice_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_order`
--
ALTER TABLE `ht_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Set Auto Increment Id Here';
--
-- AUTO_INCREMENT for table `ht_parameter_master`
--
ALTER TABLE `ht_parameter_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ht_players_notes`
--
ALTER TABLE `ht_players_notes`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ht_players_rating`
--
ALTER TABLE `ht_players_rating`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `ht_position_master`
--
ALTER TABLE `ht_position_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `ht_position_parameter_child_rating_set`
--
ALTER TABLE `ht_position_parameter_child_rating_set`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_position_parameter_child_rating_set1`
--
ALTER TABLE `ht_position_parameter_child_rating_set1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=290;
--
-- AUTO_INCREMENT for table `ht_position_team_mapping`
--
ALTER TABLE `ht_position_team_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=227;
--
-- AUTO_INCREMENT for table `ht_school`
--
ALTER TABLE `ht_school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ht_season_category`
--
ALTER TABLE `ht_season_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `ht_season_category_type_set`
--
ALTER TABLE `ht_season_category_type_set`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `ht_state`
--
ALTER TABLE `ht_state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_subscription_configuration_manager`
--
ALTER TABLE `ht_subscription_configuration_manager`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_subscription_configuration_master`
--
ALTER TABLE `ht_subscription_configuration_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Set Auto Increment value';
--
-- AUTO_INCREMENT for table `ht_subscription_master`
--
ALTER TABLE `ht_subscription_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Set Auto Increment Id', AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ht_team_registration`
--
ALTER TABLE `ht_team_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `ht_tokens`
--
ALTER TABLE `ht_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ht_user_registration`
--
ALTER TABLE `ht_user_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `ht_user_team_mapping`
--
ALTER TABLE `ht_user_team_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
--
-- AUTO_INCREMENT for table `ht_zipcode`
--
ALTER TABLE `ht_zipcode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `ht_aclrolepermission`
--
ALTER TABLE `ht_aclrolepermission`
  ADD CONSTRAINT `ht_aclrolepermission_ibfk_1` FOREIGN KEY (`permID`) REFERENCES `ht_aclpermission` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_aclrolepermission_ibfk_2` FOREIGN KEY (`roleId`) REFERENCES `ht_aclroles` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_cities`
--
ALTER TABLE `ht_cities`
  ADD CONSTRAINT `ht_cities_ibfk_1` FOREIGN KEY (`countryId`) REFERENCES `ht_countries` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_cities_ibfk_2` FOREIGN KEY (`stateId`) REFERENCES `ht_state` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_invoice`
--
ALTER TABLE `ht_invoice`
  ADD CONSTRAINT `ht_invoice_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `ht_user_registration` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_invoice_payment`
--
ALTER TABLE `ht_invoice_payment`
  ADD CONSTRAINT `ht_invoice_payment_ibfk_1` FOREIGN KEY (`invoiceId`) REFERENCES `ht_invoice` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_order`
--
ALTER TABLE `ht_order`
  ADD CONSTRAINT `ht_order_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `ht_user_registration` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_players_notes`
--
ALTER TABLE `ht_players_notes`
  ADD CONSTRAINT `ht_players_notes_ibfk_1` FOREIGN KEY (`coach_id`) REFERENCES `ht_user_registration` (`id`),
  ADD CONSTRAINT `ht_players_notes_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `ht_user_registration` (`id`);

--
-- Constraints for table `ht_players_rating`
--
ALTER TABLE `ht_players_rating`
  ADD CONSTRAINT `ht_players_rating_ibfk_1` FOREIGN KEY (`position_id`) REFERENCES `ht_position_master` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ht_players_rating_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `ht_user_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ht_players_rating_ibfk_3` FOREIGN KEY (`position_id`) REFERENCES `ht_position_master` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ht_position_master`
--
ALTER TABLE `ht_position_master`
  ADD CONSTRAINT `ht_position_master_ibfk_1` FOREIGN KEY (`parentId`) REFERENCES `ht_position_master` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_position_master_ibfk_2` FOREIGN KEY (`parameterId`) REFERENCES `ht_parameter_master` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_position_parameter_child_rating_set`
--
ALTER TABLE `ht_position_parameter_child_rating_set`
  ADD CONSTRAINT `ht_position_parameter_child_rating_set_ibfk_1` FOREIGN KEY (`parameterId`) REFERENCES `ht_parameter_master` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_position_parameter_child_rating_set_ibfk_2` FOREIGN KEY (`positionId`) REFERENCES `ht_position_master` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_position_parameter_child_rating_set_ibfk_3` FOREIGN KEY (`role_id`) REFERENCES `ht_aclroles` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_position_parameter_child_rating_set_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `ht_user_registration` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_position_parameter_child_rating_set_ibfk_5` FOREIGN KEY (`teamId`) REFERENCES `ht_team_registration` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_position_team_mapping`
--
ALTER TABLE `ht_position_team_mapping`
  ADD CONSTRAINT `ht_position_team_mapping_ibfk_1` FOREIGN KEY (`teamId`) REFERENCES `ht_team_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ht_school`
--
ALTER TABLE `ht_school`
  ADD CONSTRAINT `ht_school_ibfk_1` FOREIGN KEY (`countryId`) REFERENCES `ht_countries` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_school_ibfk_2` FOREIGN KEY (`stateId`) REFERENCES `ht_state` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_school_ibfk_3` FOREIGN KEY (`zipcodeId`) REFERENCES `ht_zipcode` (`id`),
  ADD CONSTRAINT `ht_school_ibfk_4` FOREIGN KEY (`cityId`) REFERENCES `ht_cities` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_season_category`
--
ALTER TABLE `ht_season_category`
  ADD CONSTRAINT `ht_season_category_ibfk_1` FOREIGN KEY (`parentId`) REFERENCES `ht_season_category` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_season_category_type_set`
--
ALTER TABLE `ht_season_category_type_set`
  ADD CONSTRAINT `ht_season_category_type_set_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `ht_user_registration` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_season_category_type_set_ibfk_3` FOREIGN KEY (`seasonId`) REFERENCES `ht_season_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ht_season_category_type_set_ibfk_4` FOREIGN KEY (`teamId`) REFERENCES `ht_team_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ht_season_category_type_set_ibfk_5` FOREIGN KEY (`roleId`) REFERENCES `ht_aclroles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ht_state`
--
ALTER TABLE `ht_state`
  ADD CONSTRAINT `ht_state_ibfk_1` FOREIGN KEY (`countryId`) REFERENCES `ht_countries` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_subscription_configuration_manager`
--
ALTER TABLE `ht_subscription_configuration_manager`
  ADD CONSTRAINT `ht_subscription_configuration_manager_ibfk_1` FOREIGN KEY (`configurationId`) REFERENCES `ht_subscription_configuration_master` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_subscription_configuration_manager_ibfk_2` FOREIGN KEY (`couponId`) REFERENCES `ht_coupon` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_subscription_configuration_manager_ibfk_3` FOREIGN KEY (`subscriptionId`) REFERENCES `ht_subscription_master` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_subscription_configuration_manager_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `ht_user_registration` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_tokens`
--
ALTER TABLE `ht_tokens`
  ADD CONSTRAINT `ht_tokens_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `ht_user_registration` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_user_registration`
--
ALTER TABLE `ht_user_registration`
  ADD CONSTRAINT `ht_user_registration_ibfk_2` FOREIGN KEY (`subconfigId`) REFERENCES `ht_subscription_configuration_manager` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_user_registration_ibfk_3` FOREIGN KEY (`teamId`) REFERENCES `ht_team_registration` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_user_registration_ibfk_4` FOREIGN KEY (`roleId`) REFERENCES `ht_aclroles` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Constraints for table `ht_user_team_mapping`
--
ALTER TABLE `ht_user_team_mapping`
  ADD CONSTRAINT `ht_user_team_mapping_ibfk_1` FOREIGN KEY (`teams_id`) REFERENCES `ht_team_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ht_zipcode`
--
ALTER TABLE `ht_zipcode`
  ADD CONSTRAINT `ht_zipcode_ibfk_1` FOREIGN KEY (`countryId`) REFERENCES `ht_countries` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_zipcode_ibfk_2` FOREIGN KEY (`stateId`) REFERENCES `ht_state` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  ADD CONSTRAINT `ht_zipcode_ibfk_3` FOREIGN KEY (`cityId`) REFERENCES `ht_cities` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
